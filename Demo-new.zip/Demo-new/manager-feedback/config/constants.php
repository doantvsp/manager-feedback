<?php
return [
    'ROLE_ADMIN' => 1,
    'ROLE_EMPLOYEE' => 0,
    'NOT_REPLY' => 0,
    'REPLIED' => 1
];
