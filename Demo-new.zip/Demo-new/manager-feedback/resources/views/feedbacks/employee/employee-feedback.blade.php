@extends('layouts.employee')

@section('title', 'List Feedbacks')
@section('content')
    @if (session('status'))
        <div class="alert alert-success">
            {{ session('status') }}
        </div>
    @endif
    <h2>List Feedbacks</h2>
    <table class="table table-bordered table-striped">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Title</th>
            <th scope="col">Content</th>
            <th scope="col">Created At</th>
            <th scope="col">Status</th>
            <th scope="col">Replied At</th>
            <th scope="col">Answer</th>
        </tr>
        </thead>
        <tbody>
        @foreach($feedbacks as $key => $feedback)
            <tr>
                <th scope="row">{{$key + 1}}</th>
                <td>{{$feedback->title}}</td>
                <td>{{$feedback->content}}</td>
                <td>{{$feedback->created_at}}</td>
                <td>@if($feedback->status == config('constants.REPLIED'))Replied @else Not Reply @endif</td>
                <td>@if($feedback->reply){{$feedback->reply->created_at}}@endif</td>
                <td>@if($feedback->reply){{$feedback->reply->content}}@endif</td>
            </tr>
        @endforeach
        </tbody>
    </table>
    <a href="{{route('feedbacks.employee-create')}}"><input type="submit" class="btn btn-secondary mt-1 mb-1" value="Create Feedback"></a>
    {{$feedbacks->links()}}
@endsection
