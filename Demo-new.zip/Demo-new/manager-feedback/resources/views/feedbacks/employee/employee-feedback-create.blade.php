@extends('layouts.employee')

@section('title', 'Create Feedbacks')
@section('content')
    <h2>Create Feedback</h2>
    <form method="post" action="{{route('feedbacks.save')}}">
        <label class="required">Title:</label>
        <input type="text" class="form-control" name="title">
        @error('title')
        <div class="alert alert-danger">{{ $message }}</div>
        @enderror
        <label class="required">Content:</label>
        <textarea class="form-control" name="content_feedback"></textarea>
        @error('content_feedback')
        <div class="alert alert-danger">{{ $message }}</div>
        @enderror
        <input type="submit" class="btn btn-secondary mt-1 mb-1" value="Send">
        @csrf
    </form>
@endsection
<style>
    .required:after {
        content: " *";
        color: red;
        font-weight: 100;
    }
</style>
