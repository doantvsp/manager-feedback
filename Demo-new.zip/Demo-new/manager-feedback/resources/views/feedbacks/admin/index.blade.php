@extends('layouts.admin')

@section('title', 'List Feedbacks')
@section('content')
    @if (session('status'))
        <div class="alert alert-success">
            {{ session('status') }}
        </div>
    @endif
    <h2>List Feedbacks</h2>
    <table class="table table-bordered table-striped mb-1">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Title</th>
            <th scope="col">Content</th>
            <th scope="col">Created By</th>
            <th scope="col">Created At</th>
            <th scope="col">Status</th>
            <th scope="col">Answer</th>
            <th scope="col">Action</th>
        </tr>
        </thead>
        <tbody>
        @foreach($feedbacks as $key => $feedback)
            <tr>
                <th scope="row">{{$key + 1}}</th>
                <td>{{$feedback->title}}</td>
                <td>{{$feedback->content}}</td>
                <td>{{$feedback->user->name}}</td>
                <td>{{$feedback->created_at}}</td>
                <td>@if($feedback->status == config('constants.REPLIED'))Replied @else Not Reply @endif</td>
                <td>@if($feedback->reply){{$feedback->reply->content}}@endif</td>
                <td>@if($feedback->status == config('constants.NOT_REPLY'))<a
                        href="{{route('reply',['feedback'=>$feedback->id])}}"><i class="fa fa-reply"
                                                                                 aria-hidden="true"></i></a>@endif</td>
            </tr>
        @endforeach
        </tbody>
    </table>
    {{$feedbacks->links()}}
@endsection
