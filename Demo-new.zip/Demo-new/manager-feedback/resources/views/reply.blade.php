@extends('layouts.admin')

@section('title', 'List Feedbacks')
@section('content')
    <h2>Reply Feedback</h2>
    <label>Feedback : {{$feedback->content}}</label>
    <form method="post" action="{{route('reply.save',['feedback'=>$feedback->id])}}">
        <label class="required">Answer:</label>
        <textarea class="form-control" name="content_reply"></textarea>
        @error('content_reply')
        <div class="alert alert-danger">{{ $message }}</div>
        @enderror
        <input type="submit" class="btn btn-secondary mt-1 mb-1" value="Reply">
        @csrf
    </form>
@endsection
<style>
    .required:after {
        content: " *";
        color: red;
        font-weight: 100;
    }
</style>
