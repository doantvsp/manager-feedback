<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/



Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::group(['middleware' => 'auth'], function() {
    Route::get('/', function () {
        return view('welcome');
    });
    Route::group(['prefix' => 'admin'], function() {
        Route::get('feedbacks', 'FeedbackController@index')->name('feedbacks.index');
        Route::get('reply/{feedback}', 'ReplyController@reply')->name('reply');
        Route::post('reply/{feedback}', 'ReplyController@replySave')->name('reply.save');
    });
    Route::group(['prefix' => 'employee'], function() {
        Route::get('feedbacks', 'FeedbackController@employeeFeedbacks')->name('feedbacks.employee-feedbacks');
        Route::post('feedbacks', 'FeedbackController@employeeFeedbackStore')->name('feedbacks.save');
        Route::get('feedback-create', 'FeedbackController@employeeFeedbackCreate')->name('feedbacks.employee-create');
    });
});
