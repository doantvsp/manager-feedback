<?php $__env->startSection('title', 'Create Feedbacks'); ?>
<?php $__env->startSection('content'); ?>
    <h2>Create Feedback</h2>
    <form method="post" action="<?php echo e(route('feedbacks.save')); ?>">
        <label class="required">Title:</label>
        <input type="text" class="form-control" name="title">
        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <label class="required">Content:</label>
        <textarea class="form-control" name="content_feedback"></textarea>
        <?php $__errorArgs = ['content_feedback'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <input type="submit" class="btn btn-secondary mt-1" value="Send">
        <?php echo csrf_field(); ?>
    </form>
<?php $__env->stopSection(); ?>
<style>
    .required:after {
        content: " *";
        color: red;
        font-weight: 100;
    }
</style>

<?php echo $__env->make('layouts.employee', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/feedbacks/employee/employee-feedback-create.blade.php ENDPATH**/ ?>