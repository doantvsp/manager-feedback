<?php $__env->startSection('title', 'List Feedbacks'); ?>
<?php $__env->startSection('content'); ?>
    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
    <h2>List Feedbacks</h2>
    <table class="table table-bordered table-striped">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Title</th>
            <th scope="col">Content</th>
            <th scope="col">Created At</th>
            <th scope="col">Status</th>
            <th scope="col">Replied At</th>
            <th scope="col">Answer</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $feedbacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $feedback): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($key + 1); ?></th>
                <td><?php echo e($feedback->title); ?></td>
                <td><?php echo e($feedback->content); ?></td>
                <td><?php echo e($feedback->created_at); ?></td>
                <td><?php if($feedback->status == config('constants.REPLIED')): ?>Replied <?php else: ?> Not Reply <?php endif; ?></td>
                <td><?php if($feedback->reply): ?><?php echo e($feedback->reply->created_at); ?><?php endif; ?></td>
                <td><?php if($feedback->reply): ?><?php echo e($feedback->reply->content); ?><?php endif; ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <a href="<?php echo e(route('feedbacks.employee-create')); ?>"><input type="submit" class="btn btn-secondary mt-1 mb-1" value="Create Feedback"></a>
    <?php echo e($feedbacks->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.employee', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/feedbacks/employee/employee-feedback.blade.php ENDPATH**/ ?>