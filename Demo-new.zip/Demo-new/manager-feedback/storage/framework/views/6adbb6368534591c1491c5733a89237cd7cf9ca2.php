<?php $__env->startSection('title', 'List Feedbacks'); ?>
<?php $__env->startSection('content'); ?>
    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>
    <h2>List Feedbacks</h2>
    <table class="table table-bordered table-striped mb-1">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Title</th>
            <th scope="col">Content</th>
            <th scope="col">Created By</th>
            <th scope="col">Created At</th>
            <th scope="col">Status</th>
            <th scope="col">Answer</th>
            <th scope="col">Action</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $feedbacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $feedback): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($key + 1); ?></th>
                <td><?php echo e($feedback->title); ?></td>
                <td><?php echo e($feedback->content); ?></td>
                <td><?php echo e($feedback->user->name); ?></td>
                <td><?php echo e($feedback->created_at); ?></td>
                <td><?php if($feedback->status == config('constants.REPLIED')): ?>Replied <?php else: ?> Not Reply <?php endif; ?></td>
                <td><?php if($feedback->reply): ?><?php echo e($feedback->reply->content); ?><?php endif; ?></td>
                <td><?php if($feedback->status == config('constants.NOT_REPLY')): ?><a
                        href="<?php echo e(route('reply',['feedback'=>$feedback->id])); ?>"><i class="fa fa-reply"
                                                                                 aria-hidden="true"></i></a><?php endif; ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($feedbacks->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/feedbacks/admin/index.blade.php ENDPATH**/ ?>