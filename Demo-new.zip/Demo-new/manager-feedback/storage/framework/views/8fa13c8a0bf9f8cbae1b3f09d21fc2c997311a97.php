<?php $__env->startSection('title', 'List Feedbacks'); ?>
<?php $__env->startSection('content'); ?>
    <h2>Reply Feedback</h2>
    <label>Feedback : <?php echo e($feedback->content); ?></label>
    <form method="post" action="<?php echo e(route('reply.save',['feedback'=>$feedback->id])); ?>">
        <label class="required">Answer:</label>
        <textarea class="form-control" name="content_reply"></textarea>
        <?php $__errorArgs = ['content_reply'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="alert alert-danger"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <input type="submit" class="btn btn-secondary mt-1 mb-1" value="Reply">
        <?php echo csrf_field(); ?>
    </form>
<?php $__env->stopSection(); ?>
<style>
    .required:after {
        content: " *";
        color: red;
        font-weight: 100;
    }
</style>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/reply.blade.php ENDPATH**/ ?>