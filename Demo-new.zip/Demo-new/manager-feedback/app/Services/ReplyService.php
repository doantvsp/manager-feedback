<?php


namespace App\Services;


use App\Http\Requests\Reply\ReplySaveRequest;
use App\Models\Feedback;
use App\Repositories\ReplyRepository;

class ReplyService
{
    protected $replyRepository;

    public function __construct(ReplyRepository $replyRepository)
    {
        $this->replyRepository = $replyRepository;
    }

    /**
     * @param  Feedback  $feedback
     * @param  ReplySaveRequest  $request
     * @return mixed
     */
    public function createReply(Feedback $feedback, ReplySaveRequest $request)
    {
        return $this->replyRepository->createReply($feedback->id, $request->user(), $request->content_reply);
    }
}
