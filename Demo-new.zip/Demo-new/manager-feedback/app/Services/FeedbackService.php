<?php


namespace App\Services;


use App\Http\Requests\Employee\FeedbackSaveRequest;
use App\Repositories\FeedbackRepository;
use Carbon\Carbon;

class FeedbackService
{
    /**
     * @var FeedbackRepository
     */
    protected $feedbackRepository;

    /**
     * FeedbackService constructor.
     * @param  FeedbackRepository  $feedbackRepository
     */
    public function __construct(FeedbackRepository $feedbackRepository)
    {
        $this->feedbackRepository = $feedbackRepository;
    }

    /**
     * @return mixed
     */
    public function getAllFeedbacks()
    {
        $feedbacks = $this->feedbackRepository->getAllFeedbacks();
        return $feedbacks;
    }

    /**
     * @param  FeedbackSaveRequest  $request
     * @return mixed
     */
    public function createFeedback(FeedbackSaveRequest $request)
    {
        $feedback = $this->feedbackRepository->newModel();
        $feedback->title = $request->title;
        $feedback->content = $request->content_feedback;
        $feedback->user_id = $request->user()->id;
        $feedback->created_at = Carbon::now();
        $feedback->updated_at = Carbon::now();
        $feedback->save();
        return $feedback;
    }
}
