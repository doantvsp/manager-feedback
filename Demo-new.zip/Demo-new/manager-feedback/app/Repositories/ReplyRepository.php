<?php


namespace App\Repositories;


use App\Models\Reply;
use App\User;
use Carbon\Carbon;

class ReplyRepository extends BaseRepository
{
    /**
     * @return string
     */
    public function getModel()
    {
        return Reply::class;
    }

    /**
     * @param $feedbackId
     * @param  User  $user
     * @param $content
     * @return mixed
     */
    public function createReply($feedbackId, User $user, $content)
    {
        $reply = $this->newModel();
        $reply->content = $content;
        $reply->user_id = $user->id;
        $reply->feedback_id = $feedbackId;
        $reply->created_at = Carbon::now();
        $reply->updated_at = Carbon::now();
        $reply->save();
        return $reply;
    }
}
