<?php

namespace App\Repositories;

abstract class BaseRepository
{

    /**
     * @var
     */
    protected $model;

    /**
     * BaseRepository constructor.
     *
     * @throws \Illuminate\Contracts\Container\BindingResolutionException
     */
    public function __construct()
    {
        $this->setModel();
    }

    /**
     * @return mixed
     */
    abstract public function getModel();

    /**
     * @throws \Illuminate\Contracts\Container\BindingResolutionException
     */
    public function setModel()
    {
        $this->model = app()->make(
            $this->getModel()
        );
    }

    /**
     * @param array|null $attributes
     *
     * @return mixed
     */
    public function newModel(array $attributes = null)
    {
        $model = $this->model->newInstance($attributes);

        return $model;
    }

    public function query()
    {
        return $this->model->query();
    }

    public function create($data)
    {
        return $this->model->create($data);
    }

    public function insert($data)
    {
        return $this->model->insert($data);
    }
}
