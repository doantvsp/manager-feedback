<?php


namespace App\Repositories;

use App\Models\Feedback;

class FeedbackRepository extends BaseRepository
{
    /**
     * @return string
     */
    public function getModel()
    {
        return Feedback::class;
    }

    /**
     * @return mixed
     */
    public function getAllFeedbacks()
    {
        return $this->model->with('user')->with('reply')->paginate(20);
    }
}
