<?php

namespace App\Http\Controllers;

use App\Http\Requests\Admin\ListFeedbacksRequest;
use App\Http\Requests\Employee\FeedbackSaveRequest;
use App\Services\FeedbackService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class FeedbackController extends Controller
{
    /**
     * @var FeedbackService
     */
    protected $feedbackService;

    /**
     * FeedbackController constructor.
     * @param  FeedbackService  $feedbackService
     */
    public function __construct(FeedbackService $feedbackService)
    {
        $this->feedbackService = $feedbackService;
    }

    /**
     * @param  ListFeedbacksRequest  $request
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function index(ListFeedbacksRequest $request)
    {
        $feedbacks = $this->feedbackService->getAllFeedbacks();
        return view('feedbacks.admin.index', compact('feedbacks'));
    }

    /**
     * @param  Request  $request
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function employeeFeedbacks(Request $request)
    {
        $user = $request->user();
        $feedbacks = $user->feedbacks()->with('reply')->paginate(20);
        return view('feedbacks.employee.employee-feedback', compact('feedbacks'));
    }

    /**
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function employeeFeedbackCreate()
    {
        return view('feedbacks.employee.employee-feedback-create');
    }

    /**
     * @param  FeedbackSaveRequest  $request
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Http\RedirectResponse|\Illuminate\Routing\Redirector
     */
    public function employeeFeedbackStore(FeedbackSaveRequest $request)
    {
        $this->feedbackService->createFeedback($request);
        return redirect()->route('feedbacks.employee-feedbacks')->with('status', 'Feedback sent!');
    }
}
