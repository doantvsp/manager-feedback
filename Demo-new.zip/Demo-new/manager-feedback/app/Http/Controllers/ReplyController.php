<?php

namespace App\Http\Controllers;

use App\Http\Requests\Reply\ReplyEditRequest;
use App\Http\Requests\Reply\ReplySaveRequest;
use App\Models\Feedback;
use App\Services\ReplyService;
use Illuminate\Http\Request;

class ReplyController extends Controller
{
    /**
     * @param  Feedback  $feedback
     * @param  ReplyEditRequest  $request
     * @return \Illuminate\Contracts\Foundation\Application|\Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function reply(Feedback $feedback, ReplyEditRequest $request)
    {
        return view('reply', compact('feedback'));
    }

    /**
     * @param  Feedback  $feedback
     * @param  ReplySaveRequest  $request
     * @param  ReplyService  $service
     * @return \Illuminate\Http\RedirectResponse
     */
    public function replySave(Feedback $feedback, ReplySaveRequest $request, ReplyService $service)
    {
        $service->createReply($feedback, $request);
        // update feedback to replied
        $feedback->status = config('constants.REPLIED');
        $feedback->save();
        return redirect()->route('feedbacks.index')->with('status', 'Replied!');
    }
}
