CD vào thư mục manager-feedback
* Build docker (window 10)
- winpty docker-compose build
- winpty docker-compose up -d
* Chạy migrations
- winpty docker-compose exec app php artisan migrate
* Chạy seeder
- winpty docker-compose exec app php artisan db:seed
Default admin account : admin@gmail.com/12345678
Account employee thì có thể register sau đó tạo feedback.

